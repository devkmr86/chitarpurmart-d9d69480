import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Check, Circle, PhoneCall, XCircle } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, PageHeader } from "@/components/app/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Map } from "@/components/app/Map";
import type { MapMarker } from "@/components/app/MapView";
import { inr, ORDER_FLOW, STATUS_LABEL, RANCHI_CENTER } from "@/lib/mannu";

const CANCEL_REASONS = ["Placed by mistake", "Wrong address", "Changed mind", "Other"];
const CANCELLABLE_STATUSES = new Set(["PLACED", "ACCEPTED"]);
const RIDER_CALL_STATUSES = new Set(["PICKED_UP", "ON_THE_WAY"]);

export const Route = createFileRoute("/_authenticated/order/$orderId")({
  head: () => ({
    meta: [
      { title: "Track order — Mannu A2Z Mart" },
      { name: "description", content: "Live map tracking and status updates for your order." },
      { property: "og:title", content: "Track order — Mannu A2Z Mart" },
      { property: "og:description", content: "Follow your delivery partner in real time." },
    ],
  }),
  component: OrderTracking,
});

function OrderTracking() {
  const { orderId } = Route.useParams();
  const qc = useQueryClient();
  const [rider, setRider] = useState<{ lat: number; lng: number } | null>(null);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [cancelReason, setCancelReason] = useState<string>(CANCEL_REASONS[0]!);
  const [cancelling, setCancelling] = useState(false);

  const { data: order } = useQuery({
    queryKey: ["order", orderId],
    queryFn: async () => {
      const { data } = await supabase
        .from("orders")
        .select("*, order_items(*)")
        .eq("id", orderId)
        .maybeSingle();
      return data;
    },
  });

  useEffect(() => {
    const channel = supabase
      .channel(`order-${orderId}`)
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "orders", filter: `id=eq.${orderId}` },
        () => void qc.invalidateQueries({ queryKey: ["order", orderId] }),
      )
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "delivery_location_logs",
          filter: `order_id=eq.${orderId}`,
        },
        (payload) => {
          const row = payload.new as { latitude: number; longitude: number };
          setRider({ lat: Number(row.latitude), lng: Number(row.longitude) });
        },
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [orderId, qc]);

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const { data } = await supabase
        .from("delivery_location_logs")
        .select("latitude,longitude")
        .eq("order_id", orderId)
        .order("recorded_at", { ascending: false })
        .limit(1);
      const row = data?.[0];
      if (row && !cancelled) setRider({ lat: Number(row.latitude), lng: Number(row.longitude) });
    }
    void load();
    return () => {
      cancelled = true;
    };
  }, [orderId]);

  const { data: partner } = useQuery({
    queryKey: ["order-partner", order?.delivery_boy_id],
    enabled: !!order?.delivery_boy_id,
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("full_name,phone")
        .eq("id", order!.delivery_boy_id!)
        .maybeSingle();
      return data;
    },
  });

  const dest =
    order?.delivery_lat && order?.delivery_lng
      ? { lat: Number(order.delivery_lat), lng: Number(order.delivery_lng) }
      : RANCHI_CENTER;

  const markers: MapMarker[] = [{ ...dest, kind: "home", label: "Delivery address" }];
  if (rider) markers.push({ ...rider, kind: "rider", label: "Delivery partner" });

  const currentIdx = ORDER_FLOW.indexOf(
    (order?.status ?? "PLACED") as (typeof ORDER_FLOW)[number],
  );

  const canCancel = !!order && CANCELLABLE_STATUSES.has(order.status);
  const canCallRider = !!order && RIDER_CALL_STATUSES.has(order.status) && !!partner?.phone;

  async function confirmCancel() {
    if (!order) return;
    setCancelling(true);
    const { error } = await supabase
      .from("orders")
      .update({
        status: "CANCELLED",
        cancelled_reason: cancelReason,
        cancelled_at: new Date().toISOString(),
      })
      .eq("id", order.id);
    setCancelling(false);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Order cancelled");
    setCancelOpen(false);
    void qc.invalidateQueries({ queryKey: ["order", orderId] });
  }

  return (
    <AppShell>
      <PageHeader
        title={order?.order_no ?? "Order"}
        subtitle={order ? STATUS_LABEL[order.status] : undefined}
      />
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-4">
        <div className="overflow-hidden rounded-2xl border border-border">
          <Map
            center={rider ?? dest}
            zoom={14}
            className="h-56 w-full"
            markers={markers}
            path={rider ? [[rider.lat, rider.lng], [dest.lat, dest.lng]] : undefined}
          />
        </div>

        {order?.status !== "DELIVERED" && order?.status !== "CANCELLED" ? (
          <div className="rounded-2xl border border-primary/40 bg-primary/5 p-4 text-center">
            <p className="text-xs text-muted-foreground">Share this OTP on delivery</p>
            <p className="font-display text-3xl font-extrabold tracking-[0.4em] text-primary">
              {order?.otp}
            </p>
          </div>
        ) : null}

        {partner?.full_name ? (
          <div className="flex items-center justify-between rounded-2xl border border-border bg-card p-4">
            <div>
              <p className="text-xs text-muted-foreground">Delivery partner</p>
              <p className="font-semibold">{partner.full_name}</p>
              {!canCallRider ? (
                <p className="mt-0.5 text-[11px] text-muted-foreground">
                  Calling unlocks once your order is picked up
                </p>
              ) : null}
            </div>
            {canCallRider ? (
              <a
                href={`tel:${partner.phone}`}
                className="flex items-center gap-1.5 rounded-full bg-accent px-4 py-2 text-sm font-semibold text-accent-foreground"
              >
                <PhoneCall className="size-3.5" /> Call
              </a>
            ) : null}
          </div>
        ) : null}

        <div className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-display font-bold">Status</h2>
          <ol className="mt-3 space-y-3">
            {ORDER_FLOW.map((s, i) => {
              const done = i <= currentIdx;
              return (
                <li key={s} className="flex items-center gap-3">
                  <span
                    className={`grid size-6 place-items-center rounded-full ${
                      done ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"
                    }`}
                  >
                    {done ? <Check className="size-3.5" /> : <Circle className="size-2" />}
                  </span>
                  <span className={done ? "text-sm font-medium" : "text-sm text-muted-foreground"}>
                    {STATUS_LABEL[s]}
                  </span>
                </li>
              );
            })}
          </ol>
          {order?.status === "CANCELLED" ? (
            <Badge variant="destructive" className="mt-3">
              Order cancelled{order?.cancelled_reason ? ` · ${order.cancelled_reason}` : ""}
            </Badge>
          ) : null}
        </div>

        {canCancel ? (
          <Button
            variant="outline"
            className="w-full gap-2 border-destructive text-destructive hover:bg-destructive/5 hover:text-destructive"
            onClick={() => setCancelOpen(true)}
          >
            <XCircle className="size-4" /> Cancel order
          </Button>
        ) : null}

        <div className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-display font-bold">Bill</h2>
          <div className="mt-3 space-y-1.5 text-sm">
            {(order?.order_items ?? []).map(
              (it: { id: string; product_name: string; qty: number; line_total: number }) => (
                <div key={it.id} className="flex justify-between">
                  <span className="truncate pr-3 text-muted-foreground">
                    {it.product_name} × {it.qty}
                  </span>
                  <span>{inr(it.line_total)}</span>
                </div>
              ),
            )}
            <Row label="Item total" value={order?.subtotal ?? 0} />
            <Row label="Delivery charge" value={order?.delivery_charge ?? 0} />
            <Row label="Platform fee" value={order?.platform_fee ?? 0} />
            {order?.discount ? <Row label="Discount" value={-order.discount} /> : null}
            <div className="flex justify-between border-t border-border pt-2 font-display font-bold">
              <span>Total ({order?.payment_mode})</span>
              <span className="text-primary">{inr(order?.total ?? 0)}</span>
            </div>
          </div>
        </div>
      </main>

      <Dialog open={cancelOpen} onOpenChange={setCancelOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Cancel this order?</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">Tell us why you're cancelling — this helps the store and delivery team.</p>
          <div className="space-y-2">
            {CANCEL_REASONS.map((r) => (
              <button
                key={r}
                onClick={() => setCancelReason(r)}
                className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left text-sm ${
                  cancelReason === r ? "border-primary bg-primary/5 font-semibold" : "border-border"
                }`}
              >
                <span
                  className={`grid size-4 shrink-0 place-items-center rounded-full border-2 ${
                    cancelReason === r ? "border-primary" : "border-muted-foreground"
                  }`}
                >
                  {cancelReason === r ? <span className="size-2 rounded-full bg-primary" /> : null}
                </span>
                {r}
              </button>
            ))}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCancelOpen(false)}>
              Keep order
            </Button>
            <Button variant="destructive" disabled={cancelling} onClick={() => void confirmCancel()}>
              {cancelling ? "Cancelling…" : "Yes, cancel order"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span>{inr(value)}</span>
    </div>
  );
}
