import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Package, Plus, Trash2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AdminLayout, AdminCard } from "@/components/admin/AdminLayout";
import { ImageUpload, MoneyInput } from "@/components/admin/ImageUpload";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { logAdminAction } from "@/lib/admin-audit";
import { inr } from "@/lib/mannu";

export const Route = createFileRoute("/_authenticated/admin/products")({
  head: () => ({
    meta: [
      { title: "Product Inventory — Mannu Admin" },
      { name: "description", content: "View, add, edit or remove products for any store and toggle stock availability." },
      { property: "og:title", content: "Product Inventory — Mannu Admin" },
      { property: "og:description", content: "Master control over every store's product catalog and stock." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ProductInventory,
});

type ProductForm = {
  id?: string;
  product_name: string;
  description: string;
  price: string;
  mrp: string;
  unit_id: string;
  unit_qty: string;
  stock_qty: string;
  image_url: string | null;
};

const EMPTY_FORM: ProductForm = {
  product_name: "",
  description: "",
  price: "",
  mrp: "",
  unit_id: "",
  unit_qty: "1",
  stock_qty: "0",
  image_url: null,
};

function ProductInventory() {
  const qc = useQueryClient();
  const [storeId, setStoreId] = useState<string>("");
  const [storeSearch, setStoreSearch] = useState("");
  const [productSearch, setProductSearch] = useState("");
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState<ProductForm>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);

  const { data: stores } = useQuery({
    queryKey: ["admin-store-list-lite"],
    queryFn: async () =>
      (await supabase.from("stores").select("id,store_name,store_status").order("store_name")).data ?? [],
  });

  const { data: units } = useQuery({
    queryKey: ["admin-units"],
    queryFn: async () => (await supabase.from("units").select("id,name,short_name").order("name")).data ?? [],
  });

  const { data: products, isFetching } = useQuery({
    queryKey: ["admin-store-products", storeId],
    enabled: !!storeId,
    queryFn: async () =>
      (
        await supabase
          .from("products")
          .select("*")
          .eq("store_id", storeId)
          .order("product_name")
      ).data ?? [],
  });

  const filteredStores = useMemo(() => {
    const q = storeSearch.trim().toLowerCase();
    const list = stores ?? [];
    return q ? list.filter((s) => s.store_name.toLowerCase().includes(q)) : list;
  }, [stores, storeSearch]);

  const filteredProducts = useMemo(() => {
    const q = productSearch.trim().toLowerCase();
    const list = products ?? [];
    return q ? list.filter((p) => p.product_name.toLowerCase().includes(q)) : list;
  }, [products, productSearch]);

  const currentStore = (stores ?? []).find((s) => s.id === storeId);

  function openAdd() {
    setForm(EMPTY_FORM);
    setOpen(true);
  }

  function openEdit(p: NonNullable<typeof products>[number]) {
    setForm({
      id: p.id,
      product_name: p.product_name,
      description: p.description ?? "",
      price: String(p.price),
      mrp: p.mrp != null ? String(p.mrp) : "",
      unit_id: p.unit_id ?? "",
      unit_qty: String(p.unit_qty),
      stock_qty: String(p.stock_qty),
      image_url: p.image_url,
    });
    setOpen(true);
  }

  async function save() {
    if (!storeId) return;
    if (!form.product_name.trim()) {
      toast.error("Enter a product name");
      return;
    }
    setSaving(true);
    const payload = {
      store_id: storeId,
      product_name: form.product_name.trim(),
      description: form.description.trim() || null,
      price: Number(form.price) || 0,
      mrp: form.mrp ? Number(form.mrp) : null,
      unit_id: form.unit_id || null,
      unit_qty: Number(form.unit_qty) || 1,
      stock_qty: Number(form.stock_qty) || 0,
      image_url: form.image_url,
    };
    const res = form.id
      ? await supabase.from("products").update(payload).eq("id", form.id)
      : await supabase.from("products").insert(payload);
    setSaving(false);
    if (res.error) {
      toast.error(res.error.message);
      return;
    }
    toast.success(form.id ? "Product updated" : "Product added");
    void logAdminAction(form.id ? "UPDATE" : "CREATE", "products", form.id ?? null, { store_id: storeId });
    void qc.invalidateQueries({ queryKey: ["admin-store-products", storeId] });
    setOpen(false);
  }

  async function run(promise: PromiseLike<{ error: { message: string } | null }>, msg: string, audit?: { action: string; entity: string; id?: string | null }) {
    const { error } = await promise;
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(msg);
    if (audit) void logAdminAction(audit.action, audit.entity, audit.id ?? null, {});
    void qc.invalidateQueries({ queryKey: ["admin-store-products", storeId] });
  }

  return (
    <AdminLayout
      title="Product Inventory"
      subtitle="View, add, edit or remove products for any store"
      actions={
        storeId ? (
          <Button size="sm" onClick={openAdd} className="gap-1.5">
            <Plus className="size-4" /> Add product
          </Button>
        ) : undefined
      }
    >
      <AdminCard className="mb-4">
        <Label className="text-xs">Select a store</Label>
        <div className="mt-1.5 flex flex-wrap gap-2">
          <Input
            className="w-56"
            placeholder="Search stores…"
            value={storeSearch}
            onChange={(e) => setStoreSearch(e.target.value)}
          />
          <Select value={storeId} onValueChange={setStoreId}>
            <SelectTrigger className="w-64">
              <SelectValue placeholder="Choose a store" />
            </SelectTrigger>
            <SelectContent>
              {filteredStores.map((s) => (
                <SelectItem key={s.id} value={s.id}>
                  {s.store_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {currentStore ? (
            <Badge variant={currentStore.store_status === "OPEN" ? "default" : "secondary"}>
              {currentStore.store_status}
            </Badge>
          ) : null}
        </div>
      </AdminCard>

      {!storeId ? (
        <p className="rounded-2xl border border-dashed border-border p-10 text-center text-sm text-muted-foreground">
          <Package className="mx-auto mb-2 size-6 text-muted-foreground" />
          Select a store above to view and manage its products.
        </p>
      ) : (
        <>
          <Input
            className="mb-3 max-w-sm"
            placeholder="Search products in this store…"
            value={productSearch}
            onChange={(e) => setProductSearch(e.target.value)}
          />
          <div className="grid gap-3 lg:grid-cols-2">
            {filteredProducts.map((p) => (
              <AdminCard key={p.id}>
                <div className="flex items-start gap-3">
                  <div className="grid size-14 shrink-0 place-items-center overflow-hidden rounded-xl border border-border bg-muted">
                    {p.image_url ? (
                      <img src={p.image_url} alt={p.product_name} className="size-full object-cover" loading="lazy" />
                    ) : (
                      <Package className="size-5 text-muted-foreground" />
                    )}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-semibold">{p.product_name}</p>
                    <p className="mt-0.5 text-sm font-bold text-primary">
                      {inr(Number(p.price))}
                      {p.mrp ? <span className="ml-1 text-xs font-normal text-muted-foreground line-through">{inr(Number(p.mrp))}</span> : null}
                    </p>
                    <p className="text-[11px] text-muted-foreground">Stock: {Number(p.stock_qty)}</p>
                  </div>
                  <Badge variant={p.is_available ? "default" : "secondary"}>
                    {p.is_available ? "In stock" : "Out of stock"}
                  </Badge>
                </div>

                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <span className="text-xs text-muted-foreground">In stock</span>
                  <Switch
                    checked={p.is_available}
                    onCheckedChange={(v) =>
                      void run(
                        supabase.from("products").update({ is_available: v }).eq("id", p.id),
                        v ? "Marked in stock" : "Marked out of stock",
                        { action: "UPDATE", entity: "products", id: p.id },
                      )
                    }
                  />
                  <Input
                    type="number"
                    className="w-24"
                    defaultValue={String(p.stock_qty)}
                    onBlur={(e) =>
                      void run(
                        supabase.from("products").update({ stock_qty: Number(e.target.value) || 0 }).eq("id", p.id),
                        "Stock quantity updated",
                      )
                    }
                  />
                  <Button size="sm" variant="outline" onClick={() => openEdit(p)}>
                    Edit
                  </Button>
                  <Button
                    size="icon"
                    variant="ghost"
                    className="ml-auto"
                    onClick={() =>
                      void run(
                        supabase.from("products").delete().eq("id", p.id),
                        "Product removed",
                        { action: "DELETE", entity: "products", id: p.id },
                      )
                    }
                  >
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </div>
              </AdminCard>
            ))}
            {!isFetching && !filteredProducts.length ? (
              <p className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground lg:col-span-2">
                No products found for this store.
              </p>
            ) : null}
          </div>
        </>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>{form.id ? "Edit product" : "Add product"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <ImageUpload
              value={form.image_url}
              folder="products"
              label="Upload product image"
              onChange={(url) => setForm((f) => ({ ...f, image_url: url }))}
            />
            <div>
              <Label className="text-xs">Title</Label>
              <Input value={form.product_name} onChange={(e) => setForm((f) => ({ ...f, product_name: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs">Description</Label>
              <Textarea
                rows={3}
                value={form.description}
                onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))}
              />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Price</Label>
                <MoneyInput value={form.price} onChange={(v) => setForm((f) => ({ ...f, price: v }))} />
              </div>
              <div>
                <Label className="text-xs">MRP (optional)</Label>
                <MoneyInput value={form.mrp} onChange={(v) => setForm((f) => ({ ...f, mrp: v }))} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label className="text-xs">Unit</Label>
                <Select value={form.unit_id} onValueChange={(v) => setForm((f) => ({ ...f, unit_id: v }))}>
                  <SelectTrigger><SelectValue placeholder="Select unit" /></SelectTrigger>
                  <SelectContent>
                    {(units ?? []).map((u) => (
                      <SelectItem key={u.id} value={u.id}>{u.name} ({u.short_name})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Unit qty</Label>
                <Input type="number" value={form.unit_qty} onChange={(e) => setForm((f) => ({ ...f, unit_qty: e.target.value }))} />
              </div>
            </div>
            <div>
              <Label className="text-xs">Stock quantity</Label>
              <Input type="number" value={form.stock_qty} onChange={(e) => setForm((f) => ({ ...f, stock_qty: e.target.value }))} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button disabled={saving} onClick={() => void save()}>
              {form.id ? "Save changes" : "Add product"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </AdminLayout>
  );
}
