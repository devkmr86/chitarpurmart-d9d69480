import { createFileRoute } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { AdminLayout, AdminCard } from "@/components/admin/AdminLayout";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { MoneyInput } from "@/components/admin/ImageUpload";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { inr, STATUS_LABEL } from "@/lib/mannu";
import { logAdminAction } from "@/lib/admin-audit";

export const Route = createFileRoute("/_authenticated/admin/orders")({
  head: () => ({
    meta: [
      { title: "Orders Master — Mannu Admin" },
      { name: "description", content: "Full platform order list with filters, manual delivery re-assignment, cancellations and refunds." },
      { property: "og:title", content: "Orders Master — Mannu Admin" },
      { property: "og:description", content: "Operate every order end to end from one screen." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: OrdersMaster,
});

const FILTERS: { key: string; label: string; statuses: string[] }[] = [
  { key: "ALL", label: "All", statuses: [] },
  { key: "PENDING", label: "Pending", statuses: ["PLACED"] },
  { key: "PROCESSING", label: "Processing", statuses: ["ACCEPTED", "PREPARING", "READY"] },
  { key: "OUT", label: "Out for delivery", statuses: ["ASSIGNED", "PICKED_UP", "ON_THE_WAY"] },
  { key: "DELIVERED", label: "Delivered", statuses: ["DELIVERED"] },
  { key: "CANCELLED", label: "Cancelled", statuses: ["CANCELLED"] },
];

function OrdersMaster() {
  const qc = useQueryClient();
  const [filter, setFilter] = useState("ALL");

  const { data: orders } = useQuery({
    queryKey: ["admin-orders-master", filter],
    refetchInterval: 15000,
    queryFn: async () => {
      const statuses = FILTERS.find((f) => f.key === filter)?.statuses ?? [];
      let q = supabase
        .from("orders")
        .select("id,order_no,status,total,payment_mode,placed_at,delivery_boy_id,delivery_address")
        .order("placed_at", { ascending: false })
        .limit(100);
      if (statuses.length) q = q.in("status", statuses as never[]);
      const { data } = await q;
      return data ?? [];
    },
  });

  const { data: partners } = useQuery({
    queryKey: ["admin-partner-options"],
    queryFn: async () => {
      const { data: dps } = await supabase.from("delivery_profiles").select("user_id,is_online");
      const ids = (dps ?? []).map((d) => d.user_id);
      const { data: profs } = ids.length
        ? await supabase.from("profiles").select("id,full_name,phone").in("id", ids)
        : { data: [] };
      return (dps ?? []).map((d) => {
        const p = (profs ?? []).find((x) => x.id === d.user_id);
        return {
          id: d.user_id,
          label: `${p?.full_name || p?.phone || "Partner"}${d.is_online ? " · online" : ""}`,
        };
      });
    },
  });

  const { data: disputes } = useQuery({
    queryKey: ["admin-disputes"],
    refetchInterval: 20000,
    queryFn: async () => {
      const { data } = await supabase
        .from("order_disputes")
        .select("*,orders(order_no,total)")
        .order("created_at", { ascending: false });
      return data ?? [];
    },
  });

  async function reassign(orderId: string, partnerId: string) {
    const { error } = await supabase
      .from("orders")
      .update({ delivery_boy_id: partnerId, status: "ASSIGNED" })
      .eq("id", orderId);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success("Delivery partner re-assigned");
    void qc.invalidateQueries({ queryKey: ["admin-orders-master"] });
  }

  async function cancel(orderId: string, refund: boolean) {
    const { error } = await supabase
      .from("orders")
      .update({ status: "CANCELLED" })
      .eq("id", orderId);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(refund ? "Order cancelled, refund initiated" : "Order cancelled");
    void qc.invalidateQueries({ queryKey: ["admin-orders-master"] });
  }

  async function resolveDispute(id: string, status: string, refundAmount: number, refundMode: string, note: string) {
    const { error } = await supabase
      .from("order_disputes")
      .update({
        status,
        refund_amount: refundAmount,
        refund_mode: refundMode || null,
        resolution_note: note || null,
        resolved_at: status === "OPEN" ? null : new Date().toISOString(),
      })
      .eq("id", id);
    if (error) {
      toast.error(error.message);
      return;
    }
    toast.success(status === "APPROVED" ? "Refund approved" : status === "REJECTED" ? "Dispute rejected" : "Dispute updated");
    void logAdminAction("UPDATE", "order_disputes", id, { status, refund_amount: refundAmount, refund_mode: refundMode });
    void qc.invalidateQueries({ queryKey: ["admin-disputes"] });
  }

  const openDisputes = (disputes ?? []).filter((d) => d.status === "OPEN");
  const closedDisputes = (disputes ?? []).filter((d) => d.status !== "OPEN");

  return (
    <AdminLayout title="Orders Master" subtitle="Every order across the platform and refund disputes">
      <Tabs defaultValue="orders">
        <TabsList className="flex w-full flex-wrap justify-start">
          <TabsTrigger value="orders">All orders</TabsTrigger>
          <TabsTrigger value="disputes">Refund disputes ({openDisputes.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="orders" className="mt-4">
      <div className="mb-4 flex flex-wrap gap-2">
        {FILTERS.map((f) => (
          <Button
            key={f.key}
            size="sm"
            variant={filter === f.key ? "default" : "outline"}
            onClick={() => setFilter(f.key)}
          >
            {f.label}
          </Button>
        ))}
      </div>

      <div className="grid gap-3 lg:grid-cols-2">
        {(orders ?? []).map((o) => {
          const closed = o.status === "DELIVERED" || o.status === "CANCELLED";
          return (
            <AdminCard key={o.id}>
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="font-semibold">{o.order_no}</p>
                  <p className="truncate text-xs text-muted-foreground">{o.delivery_address}</p>
                  <p className="mt-1 text-[11px] text-muted-foreground">
                    {new Date(o.placed_at).toLocaleString("en-IN")} · {o.payment_mode}
                  </p>
                </div>
                <div className="text-right">
                  <Badge variant="secondary">{STATUS_LABEL[o.status] ?? o.status}</Badge>
                  <p className="mt-1 text-sm font-bold text-primary">{inr(Number(o.total))}</p>
                </div>
              </div>

              {closed ? null : (
                <div className="mt-3 flex flex-wrap items-center gap-2">
                  <Select
                    {...(o.delivery_boy_id ? { value: o.delivery_boy_id } : {})}
                    onValueChange={(v) => void reassign(o.id, v)}
                  >
                    <SelectTrigger className="w-52">
                      <SelectValue placeholder="Assign delivery partner" />
                    </SelectTrigger>
                    <SelectContent>
                      {(partners ?? []).map((p) => (
                        <SelectItem key={p.id} value={p.id}>{p.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Button size="sm" variant="outline" onClick={() => void cancel(o.id, false)}>
                    Cancel
                  </Button>
                  <Button size="sm" variant="destructive" onClick={() => void cancel(o.id, true)}>
                    Cancel & refund
                  </Button>
                </div>
              )}
            </AdminCard>
          );
        })}
        {!orders?.length ? (
          <p className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground lg:col-span-2">
            No orders in this filter.
          </p>
        ) : null}
      </div>
        </TabsContent>

        <TabsContent value="disputes" className="mt-4 space-y-4">
          <div>
            <h2 className="mb-2 font-display text-sm font-bold text-muted-foreground">Open complaints</h2>
            <div className="grid gap-3 lg:grid-cols-2">
              {openDisputes.map((d) => (
                <DisputeCard key={d.id} dispute={d} onResolve={resolveDispute} />
              ))}
              {!openDisputes.length ? (
                <p className="rounded-2xl border border-dashed border-border p-8 text-center text-sm text-muted-foreground lg:col-span-2">
                  No open refund disputes.
                </p>
              ) : null}
            </div>
          </div>

          {closedDisputes.length ? (
            <div>
              <h2 className="mb-2 font-display text-sm font-bold text-muted-foreground">Resolved</h2>
              <div className="grid gap-3 lg:grid-cols-2">
                {closedDisputes.map((d) => (
                  <DisputeCard key={d.id} dispute={d} onResolve={resolveDispute} />
                ))}
              </div>
            </div>
          ) : null}
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}

function DisputeCard({
  dispute,
  onResolve,
}: {
  dispute: {
    id: string;
    reason: string;
    details: string | null;
    status: string;
    refund_amount: number;
    refund_mode: string | null;
    resolution_note: string | null;
    created_at: string;
    orders: { order_no: string; total: number } | null;
  };
  onResolve: (id: string, status: string, refundAmount: number, refundMode: string, note: string) => Promise<void>;
}) {
  const [amount, setAmount] = useState(String(dispute.refund_amount || dispute.orders?.total || 0));
  const [mode, setMode] = useState(dispute.refund_mode ?? "WALLET");
  const [note, setNote] = useState(dispute.resolution_note ?? "");
  const closed = dispute.status !== "OPEN";

  return (
    <AdminCard>
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="font-semibold">{dispute.orders?.order_no ?? "Order"}</p>
          <p className="mt-0.5 text-xs text-muted-foreground">{dispute.reason}</p>
          {dispute.details ? <p className="mt-1 text-xs text-muted-foreground">{dispute.details}</p> : null}
          <p className="mt-1 text-[11px] text-muted-foreground">
            {new Date(dispute.created_at).toLocaleString("en-IN")}
          </p>
        </div>
        <Badge
          variant={dispute.status === "APPROVED" ? "default" : dispute.status === "REJECTED" ? "secondary" : "outline"}
        >
          {dispute.status}
        </Badge>
      </div>

      {closed ? (
        <p className="mt-3 text-xs text-muted-foreground">
          {dispute.status === "APPROVED"
            ? `Refunded ${inr(Number(dispute.refund_amount))} via ${dispute.refund_mode ?? "—"}`
            : "Rejected"}
          {dispute.resolution_note ? ` · ${dispute.resolution_note}` : ""}
        </p>
      ) : (
        <div className="mt-3 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <MoneyInput className="w-32" value={amount} onChange={setAmount} />
            <Select value={mode} onValueChange={setMode}>
              <SelectTrigger className="w-32"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="WALLET">Wallet</SelectItem>
                <SelectItem value="BANK">Bank</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Textarea
            rows={2}
            placeholder="Resolution note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
          />
          <div className="flex gap-2">
            <Button
              size="sm"
              className="flex-1"
              onClick={() => void onResolve(dispute.id, "APPROVED", Number(amount) || 0, mode, note)}
            >
              Approve refund
            </Button>
            <Button
              size="sm"
              variant="outline"
              className="flex-1"
              onClick={() => void onResolve(dispute.id, "REJECTED", 0, mode, note)}
            >
              Reject
            </Button>
          </div>
        </div>
      )}
    </AdminCard>
  );
}