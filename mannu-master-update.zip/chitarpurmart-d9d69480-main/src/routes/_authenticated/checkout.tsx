import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { CheckCircle2, CreditCard, Loader2, LocateFixed, MapPin, Plus, Wallet } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, PageHeader } from "@/components/app/AppShell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Map } from "@/components/app/Map";
import { useCart } from "@/hooks/useCart";
import { useAuth } from "@/hooks/useAuth";
import { chargeForDistance, distanceKm, inr, RANCHI_CENTER, type DeliverySlab } from "@/lib/mannu";
import { placeOrder } from "@/lib/mannu.functions";

export const Route = createFileRoute("/_authenticated/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — Mannu A2Z Mart" },
      { name: "description", content: "Choose your delivery address and place your Mannu A2Z Mart order." },
      { property: "og:title", content: "Checkout — Mannu A2Z Mart" },
      { property: "og:description", content: "Confirm address, apply coupon and pay on delivery." },
    ],
  }),
  component: Checkout,
});

type AppliedCoupon = {
  code: string;
  discount: number;
};

function Checkout() {
  const cart = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const submit = useServerFn(placeOrder);
  const [addressId, setAddressId] = useState<string | null>(null);
  const [coupon, setCoupon] = useState("");
  const [applying, setApplying] = useState(false);
  const [applied, setApplied] = useState<AppliedCoupon | null>(null);
  const [paymentMode, setPaymentMode] = useState<"COD" | "ONLINE">("COD");
  const [placing, setPlacing] = useState(false);
  const [payModalOpen, setPayModalOpen] = useState(false);
  const [payStage, setPayStage] = useState<"processing" | "success">("processing");

  const { data: addresses } = useQuery({
    queryKey: ["addresses", user?.id],
    enabled: !!user,
    queryFn: async () => {
      const { data } = await supabase
        .from("customer_addresses")
        .select("*")
        .order("is_default", { ascending: false });
      return data ?? [];
    },
  });

  useEffect(() => {
    if (!addressId && addresses?.[0]) setAddressId(addresses[0].id);
  }, [addresses, addressId]);

  const selectedAddress = (addresses ?? []).find((a) => a.id === addressId);

  const { data: store } = useQuery({
    queryKey: ["checkout-store", cart.storeId],
    enabled: !!cart.storeId,
    queryFn: async () => {
      const { data } = await supabase
        .from("stores")
        .select("id,latitude,longitude")
        .eq("id", cart.storeId!)
        .maybeSingle();
      return data;
    },
  });

  const { data: settings } = useQuery({
    queryKey: ["checkout-settings"],
    queryFn: async () => {
      const { data } = await supabase.from("system_settings").select("key,value");
      return Object.fromEntries((data ?? []).map((r) => [r.key, r.value as Record<string, unknown>]));
    },
  });

  // Live bill breakdown — mirrors the authoritative calculation the server
  // repeats (and enforces) inside placeOrder().
  const breakdown = useMemo(() => {
    const subtotal = cart.subtotal;
    const slabs = (settings?.["delivery_slabs"] as unknown as DeliverySlab[]) ?? [{ max_km: 3, charge: 20 }];
    const platformFee = Number((settings?.["platform_fee"] as { amount?: number })?.amount ?? 5);
    const freeAbove = Number((settings?.["free_delivery_above"] as { amount?: number })?.amount ?? 1e9);
    const surge = settings?.["surge"] as { active?: boolean; multiplier?: number } | undefined;

    let km = 0;
    if (store?.latitude && store?.longitude && selectedAddress?.latitude && selectedAddress?.longitude) {
      km = distanceKm(
        Number(store.latitude),
        Number(store.longitude),
        Number(selectedAddress.latitude),
        Number(selectedAddress.longitude),
      );
    }
    let deliveryCharge = subtotal > 0 ? chargeForDistance(slabs, km) : 0;
    if (surge?.active) deliveryCharge = Math.round(deliveryCharge * (surge.multiplier ?? 1));
    if (subtotal > 0 && subtotal >= freeAbove) deliveryCharge = 0;

    const discount = applied ? Math.min(applied.discount, subtotal + deliveryCharge + platformFee) : 0;
    const total = Math.max(0, subtotal + deliveryCharge + (subtotal > 0 ? platformFee : 0) - discount);
    return { subtotal, deliveryCharge, platformFee: subtotal > 0 ? platformFee : 0, discount, total, km };
  }, [cart.subtotal, settings, store, selectedAddress, applied]);

  async function applyCoupon() {
    const code = coupon.trim().toUpperCase();
    if (!code) { toast.error("Enter a coupon code"); return; }
    setApplying(true);
    const { data: row } = await supabase
      .from("coupons")
      .select("*")
      .eq("code", code)
      .eq("is_active", true)
      .maybeSingle();
    setApplying(false);
    if (!row) { toast.error("Invalid or expired coupon"); setApplied(null); return; }
    if (cart.subtotal < Number(row.min_order)) {
      toast.error(`Add ${inr(Number(row.min_order) - cart.subtotal)} more to use ${code}`);
      setApplied(null);
      return;
    }
    const discount =
      row.discount_type === "PERCENT"
        ? Math.round(Math.min((cart.subtotal * Number(row.discount_value)) / 100, Number(row.max_discount ?? Infinity)))
        : Math.round(Number(row.discount_value));
    setApplied({ code, discount });
    toast.success(`${code} applied — you saved ${inr(discount)}`);
  }

  function removeCoupon() {
    setApplied(null);
    setCoupon("");
  }

  async function finalizeOrder() {
    if (!addressId) { toast.error("Add a delivery address first"); return; }
    if (!cart.items.length) { toast.error("Your cart is empty"); return; }
    setPlacing(true);
    try {
      const order = await submit({
        data: {
          addressId,
          paymentMode,
          couponCode: applied?.code,
          items: cart.items.map((i) => ({ productId: i.productId, qty: i.qty })),
        },
      });
      if (paymentMode === "ONLINE") {
        await supabase.from("orders").update({ payment_status: "PAID" }).eq("id", order.id);
      }
      cart.clear();
      toast.success(`Order ${order.order_no} placed!`);
      navigate({ to: "/order/$orderId", params: { orderId: order.id } });
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not place order");
    } finally {
      setPlacing(false);
      setPayModalOpen(false);
    }
  }

  function handleCheckoutClick() {
    if (!addressId) { toast.error("Add a delivery address first"); return; }
    if (!cart.items.length) { toast.error("Your cart is empty"); return; }
    if (paymentMode === "COD") {
      void finalizeOrder();
      return;
    }
    // Online payment — run the simulated gateway first.
    setPlacing(true);
    setPayStage("processing");
    setPayModalOpen(true);
    setTimeout(() => {
      setPayStage("success");
      setTimeout(() => void finalizeOrder(), 900);
    }, 1400);
  }

  return (
    <AppShell>
      <PageHeader title="Checkout" subtitle={cart.storeName ?? undefined} />
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-4">
        <section className="rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold">Delivery address</h2>
            <AddressDialog
              onSaved={(id) => {
                setAddressId(id);
                void qc.invalidateQueries({ queryKey: ["addresses"] });
              }}
            />
          </div>
          <div className="mt-3 space-y-2">
            {(addresses ?? []).map((a) => (
              <button
                key={a.id}
                onClick={() => setAddressId(a.id)}
                className={`flex w-full gap-3 rounded-xl border p-3 text-left ${
                  addressId === a.id ? "border-primary bg-primary/5" : "border-border"
                }`}
              >
                <MapPin className="mt-0.5 size-4 shrink-0 text-primary" />
                <div className="min-w-0">
                  <p className="text-sm font-semibold">{a.address_type}</p>
                  <p className="text-xs text-muted-foreground">
                    {[a.house_flat_no, a.street_area, a.landmark].filter(Boolean).join(", ")}
                  </p>
                </div>
              </button>
            ))}
            {addresses?.length === 0 ? (
              <p className="text-sm text-muted-foreground">No address saved yet.</p>
            ) : null}
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-display font-bold">Order summary</h2>
          <div className="mt-3 space-y-1.5">
            {cart.items.map((i) => (
              <div key={i.productId} className="flex justify-between text-sm">
                <span className="truncate pr-3 text-muted-foreground">
                  {i.name} × {i.qty}
                </span>
                <span>{inr(i.price * i.qty)}</span>
              </div>
            ))}
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card p-4">
          <Label htmlFor="coupon">Coupon code</Label>
          {applied ? (
            <div className="mt-2 flex items-center justify-between rounded-xl border border-primary/40 bg-primary/5 px-3 py-2">
              <span className="text-sm font-semibold text-primary">
                {applied.code} applied · −{inr(applied.discount)}
              </span>
              <button className="text-xs font-medium text-muted-foreground underline" onClick={removeCoupon}>
                Remove
              </button>
            </div>
          ) : (
            <div className="mt-2 flex gap-2">
              <Input
                id="coupon"
                value={coupon}
                onChange={(e) => setCoupon(e.target.value.toUpperCase())}
                placeholder="MANNU50"
              />
              <Button variant="outline" onClick={applyCoupon} disabled={applying}>
                {applying ? <Loader2 className="size-4 animate-spin" /> : "Apply"}
              </Button>
            </div>
          )}
        </section>

        {/* Transparent, real-time bill breakdown */}
        <section className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-display font-bold">Bill details</h2>
          <div className="mt-3 space-y-1.5 text-sm">
            <Row label="Item total" value={breakdown.subtotal} />
            <Row label="Delivery charge" value={breakdown.deliveryCharge} />
            <Row label="Platform fee" value={breakdown.platformFee} />
            {breakdown.discount > 0 ? (
              <Row label={`Coupon discount (${applied?.code})`} value={-breakdown.discount} />
            ) : null}
            <div className="flex justify-between border-t border-border pt-2 font-display font-bold">
              <span>Final payable total</span>
              <span className="text-primary">{inr(breakdown.total)}</span>
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card p-4">
          <h2 className="font-display font-bold">Payment method</h2>
          <div className="mt-3 space-y-2">
            <button
              onClick={() => setPaymentMode("COD")}
              className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left ${
                paymentMode === "COD" ? "border-primary bg-primary/5" : "border-border"
              }`}
            >
              <span
                className={`grid size-5 shrink-0 place-items-center rounded-full border-2 ${
                  paymentMode === "COD" ? "border-primary" : "border-muted-foreground"
                }`}
              >
                {paymentMode === "COD" ? <span className="size-2.5 rounded-full bg-primary" /> : null}
              </span>
              <Wallet className="size-4 text-primary" />
              <div className="min-w-0">
                <p className="text-sm font-semibold">Cash on Delivery (COD)</p>
                <p className="text-xs text-muted-foreground">Pay the delivery partner when your order arrives.</p>
              </div>
            </button>
            <button
              onClick={() => setPaymentMode("ONLINE")}
              className={`flex w-full items-center gap-3 rounded-xl border p-3 text-left ${
                paymentMode === "ONLINE" ? "border-primary bg-primary/5" : "border-border"
              }`}
            >
              <span
                className={`grid size-5 shrink-0 place-items-center rounded-full border-2 ${
                  paymentMode === "ONLINE" ? "border-primary" : "border-muted-foreground"
                }`}
              >
                {paymentMode === "ONLINE" ? <span className="size-2.5 rounded-full bg-primary" /> : null}
              </span>
              <CreditCard className="size-4 text-primary" />
              <div className="min-w-0">
                <p className="text-sm font-semibold">Online Payment (UPI / Cards)</p>
                <p className="text-xs text-muted-foreground">Pay now securely via UPI, debit or credit card.</p>
              </div>
            </button>
          </div>
        </section>

        <Button className="h-12 w-full text-base" onClick={handleCheckoutClick} disabled={placing}>
          {placing ? (
            <Loader2 className="size-4 animate-spin" />
          ) : paymentMode === "COD" ? (
            `Place Order (COD) • ${inr(breakdown.total)}`
          ) : (
            `Pay Now • ${inr(breakdown.total)}`
          )}
        </Button>
      </main>

      <Dialog open={payModalOpen} onOpenChange={(v) => !placing && setPayModalOpen(v)}>
        <DialogContent className="text-center">
          <DialogHeader>
            <DialogTitle className="text-center">
              {payStage === "processing" ? "Processing payment…" : "Payment successful"}
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-3 py-4">
            {payStage === "processing" ? (
              <>
                <Loader2 className="size-10 animate-spin text-primary" />
                <p className="text-sm text-muted-foreground">
                  Simulated UPI/card payment of {inr(breakdown.total)}…
                </p>
              </>
            ) : (
              <>
                <CheckCircle2 className="size-10 text-primary" />
                <p className="text-sm text-muted-foreground">Placing your order…</p>
              </>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </AppShell>
  );
}

function Row({ label, value }: { label: string; value: number }) {
  return (
    <div className="flex justify-between">
      <span className="text-muted-foreground">{label}</span>
      <span>{inr(value)}</span>
    </div>
  );
}

function AddressDialog({ onSaved }: { onSaved: (id: string) => void }) {
  const [open, setOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [pos, setPos] = useState(RANCHI_CENTER);
  const [type, setType] = useState("Home");
  const [house, setHouse] = useState("");
  const [street, setStreet] = useState("");
  const [landmark, setLandmark] = useState("");

  function locate() {
    if (!navigator.geolocation) { toast.error("Location not supported"); return; }
    navigator.geolocation.getCurrentPosition(
      (p) => setPos({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => toast.error("Could not fetch your location"),
    );
  }

  async function save() {
    if (!house.trim() || !street.trim()) { toast.error("Fill house and area"); return; }
    setSaving(true);
    const { data: auth } = await supabase.auth.getUser();
    const { data, error } = await supabase
      .from("customer_addresses")
      .insert({
        customer_id: auth.user!.id,
        address_type: type,
        house_flat_no: house.trim(),
        street_area: street.trim(),
        landmark: landmark.trim() || null,
        latitude: pos.lat,
        longitude: pos.lng,
      })
      .select("id")
      .single();
    setSaving(false);
    if (error || !data) { toast.error(error?.message ?? "Could not save address"); return; }
    toast.success("Address saved");
    setOpen(false);
    onSaved(data.id);
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="gap-1">
          <Plus className="size-4" /> Add
        </Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>New delivery address</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="overflow-hidden rounded-xl border border-border">
            <Map
              center={pos}
              zoom={15}
              className="h-48 w-full"
              onMapClick={(lat, lng) => setPos({ lat, lng })}
              markers={[
                {
                  lat: pos.lat,
                  lng: pos.lng,
                  kind: "home",
                  draggable: true,
                  onDragEnd: (lat, lng) => setPos({ lat, lng }),
                },
              ]}
            />
          </div>
          <Button variant="outline" size="sm" className="w-full gap-2" onClick={locate}>
            <LocateFixed className="size-4" /> Use my current location
          </Button>
          <div className="grid grid-cols-3 gap-2">
            {["Home", "Work", "Other"].map((t) => (
              <button
                key={t}
                onClick={() => setType(t)}
                className={`rounded-xl border py-2 text-sm font-medium ${
                  type === t ? "border-primary bg-primary/10 text-primary" : "border-border"
                }`}
              >
                {t}
              </button>
            ))}
          </div>
          <Input value={house} onChange={(e) => setHouse(e.target.value)} placeholder="House / flat no." />
          <Input value={street} onChange={(e) => setStreet(e.target.value)} placeholder="Street / area" />
          <Input value={landmark} onChange={(e) => setLandmark(e.target.value)} placeholder="Landmark (optional)" />
          <Button className="w-full" onClick={save} disabled={saving}>
            {saving ? <Loader2 className="size-4 animate-spin" /> : "Save address"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
