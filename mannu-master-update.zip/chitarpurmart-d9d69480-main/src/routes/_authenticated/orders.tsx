import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { toast } from "sonner";
import { ClipboardList, RotateCcw } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { AppShell, PageHeader } from "@/components/app/AppShell";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useCart, type CartItem } from "@/hooks/useCart";
import { inr, STATUS_LABEL } from "@/lib/mannu";

export const Route = createFileRoute("/_authenticated/orders")({
  head: () => ({
    meta: [
      { title: "My orders — Mannu A2Z Mart" },
      { name: "description", content: "Track your current and past Mannu A2Z Mart orders." },
      { property: "og:title", content: "My orders — Mannu A2Z Mart" },
      { property: "og:description", content: "Live status of every order you placed." },
    ],
  }),
  component: Orders,
});

function Orders() {
  const { user } = useAuth();
  const cart = useCart();
  const navigate = useNavigate();

  // Strict isolation: only orders this person placed as a CUSTOMER —
  // never store-received orders, even if this account is also a Seller.
  const { data: orders } = useQuery({
    queryKey: ["my-orders", user?.id],
    enabled: !!user,
    refetchInterval: 15000,
    queryFn: async () => {
      const { data } = await supabase
        .from("orders")
        .select("id,order_no,status,total,placed_at,delivery_address")
        .eq("customer_id", user!.id)
        .order("placed_at", { ascending: false });
      return data ?? [];
    },
  });

  async function reorder(orderId: string) {
    const { data: items } = await supabase
      .from("order_items")
      .select("store_id,product_id,qty,product_name")
      .eq("order_id", orderId);
    if (!items?.length) {
      toast.error("Could not load this order's items");
      return;
    }
    const firstStoreId = items[0]!.store_id;
    const sameStoreItems = items.filter((i) => i.store_id === firstStoreId);
    const productIds = sameStoreItems.map((i) => i.product_id).filter(Boolean) as string[];

    const { data: products } = await supabase
      .from("products")
      .select("id,product_name,price,is_available,image_url,unit_qty,store_id,units(short_name),stores(store_name)")
      .in("id", productIds);

    const cartItems: CartItem[] = [];
    let skipped = 0;
    for (const line of sameStoreItems) {
      const p = (products ?? []).find((x) => x.id === line.product_id);
      if (!p || !p.is_available) {
        skipped++;
        continue;
      }
      cartItems.push({
        productId: p.id,
        name: p.product_name,
        price: Number(p.price),
        qty: line.qty,
        unitLabel: `${p.unit_qty} ${(p.units as { short_name?: string } | null)?.short_name ?? ""}`.trim(),
        storeId: p.store_id,
        storeName: (p.stores as { store_name?: string } | null)?.store_name ?? "Store",
        imageUrl: p.image_url,
      });
    }
    if (!cartItems.length) {
      toast.error("None of these items are available right now");
      return;
    }
    cart.replaceAll(cartItems);
    if (skipped || items.length > sameStoreItems.length) {
      toast.success(`Added ${cartItems.length} item(s) to cart — some items from this order weren't available`);
    } else {
      toast.success("Items added to cart");
    }
    navigate({ to: "/cart" });
  }

  return (
    <AppShell>
      <PageHeader title="My orders" />
      <main className="mx-auto max-w-3xl space-y-3 px-4 py-4">
        {(orders ?? []).map((o) => (
          <div key={o.id} className="rounded-2xl border border-border bg-card p-4">
            <Link to="/order/$orderId" params={{ orderId: o.id }} className="block">
              <div className="flex items-center justify-between">
                <span className="font-display font-bold">{o.order_no}</span>
                <Badge variant={o.status === "DELIVERED" ? "secondary" : "default"}>
                  {STATUS_LABEL[o.status] ?? o.status}
                </Badge>
              </div>
              <p className="mt-1 truncate text-xs text-muted-foreground">{o.delivery_address}</p>
              <div className="mt-2 flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {new Date(o.placed_at).toLocaleString("en-IN")}
                </span>
                <span className="font-bold text-primary">{inr(o.total)}</span>
              </div>
            </Link>
            {o.status === "DELIVERED" ? (
              <Button
                size="sm"
                variant="outline"
                className="mt-3 w-full gap-1.5"
                onClick={() => void reorder(o.id)}
              >
                <RotateCcw className="size-3.5" /> Reorder
              </Button>
            ) : null}
          </div>
        ))}
        {orders?.length === 0 ? (
          <div className="rounded-3xl border border-dashed border-border p-10 text-center">
            <ClipboardList className="mx-auto size-8 text-muted-foreground" />
            <p className="mt-3 font-semibold">No orders yet</p>
            <Button asChild className="mt-4">
              <Link to="/">Browse stores</Link>
            </Button>
          </div>
        ) : null}
      </main>
    </AppShell>
  );
}
