-- ============================================================
-- Master update: payment status/cancellation columns +
-- idempotent RLS hardening so any authenticated customer can
-- always insert their own orders/order_items.
-- ============================================================

-- Track online-payment status and cancellation details on orders.
-- (payment_mode already stores 'COD' / 'ONLINE' — we add payment_status
-- alongside it instead of a duplicate column.)
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS payment_status text NOT NULL DEFAULT 'PENDING';
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancelled_reason text;
ALTER TABLE public.orders ADD COLUMN IF NOT EXISTS cancelled_at timestamptz;

-- Re-assert INSERT grants (idempotent no-op if already granted).
GRANT SELECT, INSERT, UPDATE ON public.orders TO authenticated;
GRANT SELECT, INSERT ON public.order_items TO authenticated;

-- Re-create the customer INSERT policies from scratch so every
-- authenticated user — including a customer who just registered —
-- can place an order that belongs to them.
DROP POLICY IF EXISTS "orders customer insert" ON public.orders;
CREATE POLICY "orders customer insert" ON public.orders
  FOR INSERT TO authenticated
  WITH CHECK (customer_id = auth.uid());

DROP POLICY IF EXISTS "order items insert" ON public.order_items;
CREATE POLICY "order items insert" ON public.order_items
  FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.orders o WHERE o.id = order_id AND o.customer_id = auth.uid())
  );
